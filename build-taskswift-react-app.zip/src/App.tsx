import { useEffect, useMemo, useState, type FormEvent } from "react";

type Task = {
  id: number;
  title: string;
  createdAt: number;
};

const STORAGE_KEY = "taskswift.tasks";

function loadTasks(): Task[] {
  if (typeof window === "undefined") {
    return [];
  }

  try {
    const storedTasks = window.localStorage.getItem(STORAGE_KEY);
    if (!storedTasks) {
      return [];
    }

    const parsed = JSON.parse(storedTasks) as unknown;
    if (!Array.isArray(parsed)) {
      return [];
    }

    return parsed.filter((task): task is Task => {
      return (
        typeof task === "object" &&
        task !== null &&
        typeof (task as Task).id === "number" &&
        typeof (task as Task).title === "string" &&
        typeof (task as Task).createdAt === "number"
      );
    });
  } catch {
    return [];
  }
}

export default function App() {
  const [tasks, setTasks] = useState<Task[]>(loadTasks);
  const [taskTitle, setTaskTitle] = useState("");

  useEffect(() => {
    window.localStorage.setItem(STORAGE_KEY, JSON.stringify(tasks));
  }, [tasks]);

  const taskCountText = useMemo(() => {
    return tasks.length === 1 ? "1 task" : `${tasks.length} tasks`;
  }, [tasks.length]);

  function handleSubmit(event: FormEvent<HTMLFormElement>) {
    event.preventDefault();

    const title = taskTitle.trim();
    if (!title) {
      return;
    }

    setTasks((currentTasks) => [
      {
        id: Date.now(),
        title,
        createdAt: Date.now(),
      },
      ...currentTasks,
    ]);
    setTaskTitle("");
  }

  function handleDelete(id: number) {
    setTasks((currentTasks) => currentTasks.filter((task) => task.id !== id));
  }

  return (
    <div className="min-h-screen bg-slate-950 text-slate-100">
      <main className="mx-auto flex min-h-screen w-full max-w-3xl flex-col px-6 py-10 sm:px-8 lg:px-10">
        <header className="space-y-4">
          <p className="text-sm font-semibold uppercase tracking-[0.32em] text-cyan-300">
            TaskSwift
          </p>
          <h1 className="max-w-xl text-4xl font-semibold tracking-tight text-white sm:text-5xl">
            Keep your tasks local, simple, and fast.
          </h1>
          <p className="max-w-xl text-base leading-7 text-slate-300 sm:text-lg">
            Add a task, delete it when you are done, and keep everything saved in your browser.
          </p>
        </header>

        <form
          onSubmit={handleSubmit}
          className="mt-10 flex flex-col gap-3 sm:flex-row sm:items-center"
        >
          <label className="sr-only" htmlFor="task-input">
            Task title
          </label>
          <input
            id="task-input"
            value={taskTitle}
            onChange={(event) => setTaskTitle(event.target.value)}
            placeholder="Write a task and press Enter"
            className="h-14 flex-1 rounded-2xl border border-white/10 bg-white/5 px-4 text-base text-white outline-none transition placeholder:text-slate-500 focus:border-cyan-400 focus:bg-white/[0.08]"
          />
          <button
            type="submit"
            className="inline-flex h-14 items-center justify-center rounded-2xl bg-cyan-400 px-6 font-semibold text-slate-950 transition hover:bg-cyan-300 focus:outline-none focus:ring-2 focus:ring-cyan-300 focus:ring-offset-2 focus:ring-offset-slate-950"
          >
            Add Task
          </button>
        </form>

        <section className="mt-10">
          <div className="flex items-center justify-between gap-4">
            <h2 className="text-lg font-semibold text-white">Tasks</h2>
            <p className="text-sm text-slate-400">{taskCountText}</p>
          </div>

          <div className="mt-4">
            {tasks.length === 0 ? (
              <div className="rounded-2xl border border-dashed border-white/10 bg-white/5 px-5 py-10 text-slate-400">
                No tasks yet. Add your first one above.
              </div>
            ) : (
              <ul className="divide-y divide-white/10 overflow-hidden rounded-2xl border border-white/10 bg-white/5">
                {tasks.map((task) => (
                  <li key={task.id} className="flex items-center justify-between gap-4 px-5 py-4">
                    <div className="min-w-0">
                      <p className="truncate text-base font-medium text-white">{task.title}</p>
                      <p className="mt-1 text-xs uppercase tracking-[0.25em] text-slate-500">
                        Local only
                      </p>
                    </div>
                    <button
                      type="button"
                      onClick={() => handleDelete(task.id)}
                      className="shrink-0 rounded-full border border-white/10 px-3 py-1.5 text-sm font-medium text-slate-300 transition hover:border-rose-400/40 hover:bg-rose-400/10 hover:text-rose-200"
                    >
                      Delete
                    </button>
                  </li>
                ))}
              </ul>
            )}
          </div>
        </section>
      </main>
    </div>
  );
}
